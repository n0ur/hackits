[center][size=14pt][b]Google Analytics[/b][/size][/center]
[hr]
[table][tr]
[td][b]Original Author:[/b] [url=http://www.simplemachines.org/community/index.php?action=profile;u=265135][b]Arantor[/b][/url][/td]
[td] | [b]Current Author:[/b] [url=http://www.simplemachines.org/community/index.php?action=profile;u=1][b]SMF Customization Team[/b][/url][/td]
[/tr][/table]
[table][tr]
[td][b]Supported Languages:[/b] English, Arabic, Turkish[/td]
[/tr][/table]
[table][tr][td]
[url=http://custom.simplemachines.org/mods/index.php?mod=2312][b]Link To Mod[/b][/url] | [url=http://www.simplemachines.org/community/index.php?topic=353698.0][b]Mod Discussion[/b][/url] | [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=1][b]Other SMF Customization Team Mods[/b][/url][/td]
[/tr][/table]
[hr]
[color=blue][b]Summary:[/b][/color]
This mod allows a user to specify their Google Analytics code, e.g. UA-00000000-0, in the admin panel and the appropriate loader code will be added automatically.

With 2.0 RC4 forward it should work on any theme (no theme edits).
With 1.1 it supports Classic and Babylon themes, in addition to SMF's default theme.

[color=blue][b]Compatibility:[/b][/color]
Compatible with SMF 1.1 & 2.0.x

[color=blue][b]Installation Information:[/b][/color]
The Package Manager should work in most cases, if you have problems installing please use the discussion thread as well as [url=http://docs.simplemachines.org/index.php?topic=402]Manual Installation of Mods[/url]

[color=blue][b]Change Log:[/b][/color]
[size=8pt][b]1.4 - 4 March 2011[/b]
Fixed error with mod breaking XML responses
[size=8pt][b]1.3 - 10 February 2011[/b]
2.0 RC4+ no longer requires any theme edits
Updated language support
Changed analytic javascript code to latest Google recommendations
[size=8pt][b]1.2 - 19 January 2011[/b]
Added support for 2.0 RC4
[size=8pt][b]1.1 - 22 October 2009[/b]
Added support for 2.0 RC2
[size=8pt][b]1.0 - October 14, 2009[/b]
Initial release
[/size]